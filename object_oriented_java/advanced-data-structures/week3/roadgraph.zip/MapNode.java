package roadgraph;

import java.util.LinkedList;
import java.util.List;
import geography.GeographicPoint;

public class MapNode {
	private GeographicPoint location;
	private List<MapNode> neighbors;
	private String roadName;
	private String roadType;
	private double length;
	
	public MapNode(GeographicPoint location){
		this.location = location;
		neighbors = new LinkedList<MapNode>();
		roadName = "";
		roadType = "";
		length = 0;
	}
	
	public void addNeighbor(MapNode neighbor) 
	{
		neighbors.add(neighbor);
	}
	
	public void setRoadName(String roadName) {
		this.roadName = roadName;
	}
	
	public void setRoadType(String roadType) {
		this.roadType = roadType;
	}
	
	public void setLength(double length) {
		this.length = length;
	}
	
	public List<MapNode> getNeighbors() 
	{
		return neighbors;
	}
	
	public String getRoadName() 
	{
		return roadName;
	}
	
	public String getRoadType() 
	{
		return roadType;
	}
	
	public double getLength() 
	{
		return length;
	}
	
	public GeographicPoint getLocation() 
	{
		return location;
	}
}
